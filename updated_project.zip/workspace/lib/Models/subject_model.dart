class SubjectModel {
  final int id;
  final String title;

  SubjectModel({required this.id, required this.title});
}
