package com.example.avtoskola_varketilshi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
